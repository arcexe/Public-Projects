from django.apps import AppConfig


class ComingsoonConfig(AppConfig):
    name = 'comingsoon'
