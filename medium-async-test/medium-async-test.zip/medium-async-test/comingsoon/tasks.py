from __future__ import absolute_import
from bs4 import BeautifulSoup
import pandas as pd
import json
from celery import shared_task
import numpy as np
import requests

#celery shared task
@shared_task
def gen_csv():
    url = "https://en.wikipedia.org/wiki/List_of_countries_and_dependencies_by_population"
    html_doc = requests.get(url).text
    soup = BeautifulSoup(html_doc, 'html.parser')
    tables = soup.find_all('table')
    list_of_countries = pd.DataFrame(columns=['Country', 'Region', 'Population', 'Percentage'])
    for row in tables[0].tbody.find_all("tr"):
        col = row.find_all('td')
        if (col != []):
            country = col[0].text        
            region = col[1].text
            population = col[2].text
            per_of_world = col[3].text
            list_of_countries = list_of_countries.append({'Country': country, 'Region': region, 'Population': population, 'Percentage': per_of_world}, ignore_index=True)

    list_of_countries.to_csv('test.csv')

