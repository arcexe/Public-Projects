from __future__ import absolute_import
from bs4 import BeautifulSoup
import pandas as pd
import requests
from django.shortcuts import render
from django.template.loader import get_template
from xhtml2pdf import pisa
from io import BytesIO
import json
from celery import shared_task
from django.shortcuts import render
import requests
import pandas as pd
import json
import numpy as np
from io import BytesIO 
from azure.storage.blob import BlobServiceClient, BlobClient, ContainerClient
from django.http import HttpResponse
from django.template.loader import get_template
from xhtml2pdf import pisa  
import datetime
import socket
from comingsoon.tasks import gen_csv

def main_task(request):
    gen_csv.delay()
    response_data = {"Your CSV is being generated"}
    return HttpResponse(response_data, content_type='application/json')    
    
